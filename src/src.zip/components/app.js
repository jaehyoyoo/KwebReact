import React from 'react';
import ReactDOM from 'react-dom';
import Content from './content.js';

var App = React.createClass ({
    getInitialState() {
        return {
          STATE : 0,      /* STATE : 0 for main, 1 재효, 2 명훈, 3 소라, 4 현식 */
        };
    },
    state_change: function(num){
        this.setState({
            STATE:num
        });
    },
    render: function () {
        return (
        <div>
            <div id="main_navigator">
                <table className="maintable">
                    <tbody>
                        <tr>
                        <th>
                            <a href="javascript:void(0);" onClick={this.state_change.bind(this,0)}> KWEB REACT STUDY </a>
                        </th>
                        <td>
                            <a className="main_title" href="javascript:void(0);" onClick={this.state_change.bind(this,1)}>재효</a>
                        </td>
                        <td>
                            <a className="main_title" href="javascript:void(0);" onClick={this.state_change.bind(this,2)}>명훈</a>
                        </td>
                        <td>
                            <a className="main_title" href="javascript:void(0);" onClick={this.state_change.bind(this,3)}>소라</a>
                        </td>
                        <td>
                            <a className="main_title" href="javascript:void(0);" onClick={this.state_change.bind(this,4)}>현식</a>
                        </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <Content STATE={this.state.STATE} />
        </div>
        );
    }
});

export default App;