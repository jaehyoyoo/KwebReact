import React from 'react';
import ReactDOM from 'react-dom';

var Description = React.createClass({
  render: function(){
    return(
      <div>
        {
          this.props.info.map((data, i) => {
              return (<p key={i} className = "skill-detail">{data}</p>);
          })
        }
      </div>
    );
  }
});

export default Description;
