import React from 'react';
import ReactDOM from 'react-dom';
import SkillboxRender from './hyunsik_skillrender.js';
import { connect } from 'react-redux';
import { setHyunsikState } from '../actions';

class Hyunsik extends React.Component {
  constructor(props){
     super(props);
     this.onChange = this.onChange.bind(this);
  }
  render (){
    return (
      <div>
        <div className = "genji">겐지 스킬설명
          <a onClick={this.onChange.bind(this,1)}>수리검 </a>
          <a onClick={this.onChange.bind(this,2)}>튕겨내기 </a>
          <a onClick={this.onChange.bind(this,3)}>질풍참 </a>
          <a onClick={this.onChange.bind(this,4)}>용검 </a>
          <a onClick={this.onChange.bind(this,5)}>모두보기</a>
        </div>
        <SkillboxRender />
      </div>
    );
  }
  onChange(val) {
    this.props.state_change(val);
    console.log(val);
  }
}

let mapDispatchToProps = (dispatch) => {
    return {
        state_change: (value) => dispatch(setHyunsikState(value))
    };
}

let mapStateToProps = (state) => {
    return {
        change: state.switchHyunsik.value
    };
}

Hyunsik = connect(mapStateToProps, mapDispatchToProps)(Hyunsik);

export default Hyunsik;
