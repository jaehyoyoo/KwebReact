import React from 'react';
import ReactDOM from 'react-dom';
import Jaehyo from './jaehyo.js';
import Hyunsik from './hyunsik.js';
import Sora from './sora.js';

var Content = React.createClass ({
    render: function () {
        if(this.props.STATE == 0){
            return (
                <div id ="main_home">
                    Welcom to KWEB React Study.
                    Here, we are learning about Front WebFramework, REACT. Woah! React! A meo ra go deo sseo ya ha ji... hal mal i up da. eo ddeoek ha ji... <br/>
                    Everyone! have a nice day with BonoBono and jeongbo dae top dongari KWEB. We're hoping to hear your studies every gyeok ju!
                    <br/> A gundae JinJJaro deo SSul mal i up nae yo... I'm too sorry. E geo da read hal saram eo cha pi up gaet ji...
                </div>
            );
        }
        else if(this.props.STATE == 1){
            return (
                <Jaehyo />
            );
        }
        else if(this.props.STATE == 4){
          return (
                <Hyunsik />
          );
        }
        else if (this.props.STATE == 3){
            return (
                <Sora />
            );
        }
        else{
            return(
                <div> 준비중입니다 ^^ </div>
            );
        }
    }
});

export default Content;
