import React from 'react';
import ReactDOM from 'react-dom';
import Srklue from './ddd.js';

var divstyle = {
    divdiv: {
        border: 0.5,
        border: 'solid black',
        textAlign: 'center',
        padding: 10,
    },
    divdiv2: {
        border: 0.5,
        border: 'solid black',
        textAlign: 'left',
        marginTop: 10,
        padding: 100
    }
}


var Sora = React.createClass ({
    getInitialState() {
        return ({
            STATE:0
        });
    },

    onClick1: function () {
        this.setState({STATE:1});
    },
    onClick2: function () {
        this.setState({STATE:2});
    },
    onClick3: function () {
        this.setState({STATE:3});
    },
    onClick4: function () {
        this.setState({STATE:4});
    },
    onClick5: function () {
        this.setState({STATE:5});
    },
    onClick6: function () {
        this.setState({STATE:6});
    },
    onClick7: function () {
        this.setState({STATE:7});
    },
    onClick8: function () {
        this.setState({STATE:8});
    },


    render: function () {
        return (
            <div>
                <h1>이소라 전공강의 주관적 수강평</h1>
                <table style ={divstyle.divdiv}>
                    <tr>
                        <button onClick={this.onClick1.bind(this)} style = {{marginRight : 10}}>김종규<br />자료구조</button>
                        <button onClick={this.onClick2.bind(this)} style = {{marginRight : 10}}>이희조<br />계산이론</button>
                        <button onClick={this.onClick3.bind(this)} style = {{marginRight : 10}}>박성빈<br />이산수학</button>
                        <button onClick={this.onClick4.bind(this)} style = {{marginRight : 10}}>서태원<br />논리설계</button>
                        <button onClick={this.onClick5.bind(this)} style = {{marginRight : 10}}>정성우<br />컴퓨터구조</button>
                        <button onClick={this.onClick6.bind(this)} style = {{marginRight : 10}}>박성빈<br />알고리즘</button>
                        <button onClick={this.onClick7.bind(this)} style = {{marginRight : 10}}>오학주<br />프로그래밍언어</button>
                        <button onClick={this.onClick8.bind(this)}>김효곤<br />데이터통신</button>
                    </tr>
                    <tr>
                        <div style = {divstyle.divdiv2}><Srklue variable = {this.state.STATE} /></div>
                    </tr>
                </table>
                
            </div>
        );
    }
});

export default Sora;