import React from 'react';
import ReactDOM from 'react-dom';
import Skillbox from './hyunsik_skillbox.js'
import {connect} from 'react-redux';

class SkillboxRender extends React.Component{
  constructor(props){
     super(props);
    this.state = {
      shuriken : ["별 모양의 수리검 3개를 연속으로 던집니다. 수리검 3개를 한꺼번에 부채꼴로 던질 수도 있습니다.", "탄창: 24발", "재장전: 1초", "공격속도: 초당 1회(좌클릭)/초당 2회(우클릭)", "공격력: 발당 28(총 84)"],
      deflect : ["번개처럼 빠르게 검을 휘둘러 자신에게 날아오는 투사체를 적에게 튕겨냅니다.", "지속시간: 2초", "재사용시간: 8초"],
      swiftstrike : ["바람을 가르며 튀어나가 대상을 베고 지나갑니다. 이 기술로 대상을 처치하면 바로 다시 사용할 수 있습니다.", "재사용시간: 8초", "공격력: 50"],
      dragonblade : ["짧은 시간 동안 검을 뽑습니다. 용검은 근접한 대상에게 치명적인 피해를 줍니다", "지속시간: 6초","공격속도: 초당 1회", "공격력: 120"]
    };
  }
  render (){
    if(this.props.change == 0){
      return(<div>nothing</div>);
    }
    else if(this.props.change == 1){
        return (
          <div className = "shuriken skill-box">
            <Skillbox skillName = "수리검(Shuriken)" imgsrc = "./image/shuriken.png" info = {this.state.shuriken}/>
          </div>
        );
    }
    else if(this.props.change == 2){
        return (
          <div className = "deflect skill-box">
            <Skillbox skillName = "튕겨내기(Deflect)" imgsrc = "./image/deflect.png" info = {this.state.deflect}/>
          </div>
        );
    }
    else if(this.props.change == 3){
      return (
        <div className = "swiftstrike skill-box">
          <Skillbox skillName = "질풍참(Swift Strike)" imgsrc = "./image/swiftstrike.png" info = {this.state.swiftstrike}/>
        </div>
      );
    }
    else if(this.props.change == 4){
        return(
            <div className = "dragonblade skill-box">
              <Skillbox skillName = "용검(Dragon Blade)" imgsrc = "./image/dragonblade.png" info = {this.state.dragonblade}/>
            </div>
        );
    }
    else if(this.props.change == 5){
      return(
        <div>
        <div className = "shuriken skill-box">
          <Skillbox skillName = "수리검(Shuriken)" imgsrc = "./image/shuriken.png" info = {this.state.shuriken}/>
        </div>
        <div className = "deflect skill-box">
          <Skillbox skillName = "튕겨내기(Deflect)" imgsrc = "./image/deflect.png" info = {this.state.deflect}/>
        </div>
        <div className = "swiftstrike skill-box">
          <Skillbox skillName = "질풍참(Swift Strike)" imgsrc = "./image/swiftstrike.png" info = {this.state.swiftstrike}/>
        </div>
        <div className = "dragonblade skill-box">
          <Skillbox skillName = "용검(Dragon Blade)" imgsrc = "./image/dragonblade.png" info = {this.state.dragonblade}/>
        </div>
        </div>
      );
    }
  }
};


let mapStateToProps = (state) => {
    return {
        change: state.switchHyunsik.value
    };
}

SkillboxRender = connect(mapStateToProps)(SkillboxRender);

export default SkillboxRender;
