import React from 'react';
import ReactDOM from 'react-dom';

var Profile = React.createClass ({
    set_search: function(str){
        document.getElementById("search_engine").value = str;
    },
    render: function () {
        return (
      		<div className="user_profile">
                <table>
                    <tbody>
                        <tr>
                        <th>
                            <img className="user_img" src={this.props.SRC} />
                        </th>
                        <td>
                            <div className="user_name">
                                {this.props.NAME}
                            </div>
                            <div>
                                {
                                    this.props.TAG.map((data, i) => {
                                        if(data == this.props.keyword){
                                            return(
                                                <a key={i} className="hash_tag_blue" href="javascript:void(0);" onClick={this.set_search.bind(this,data)}>{data}</a>
                                            );
                                        }
                                        else{
                                            return(
                                                <a key={i} className="hash_tag" href="javascript:void(0);" onClick={this.set_search.bind(this,data)}>{data}</a>
                                            );
                                        }
                                    }) 
                                }
                            </div>
                        </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        );
    }
});

export default Profile;