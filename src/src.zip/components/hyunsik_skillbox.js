import React from 'react';
import ReactDOM from 'react-dom';
import Description from './hyunsik_skillbox_description';

var Skillbox = React.createClass({
  render: function(){
    return (
      <table>
        <tbody>
          <tr>
            <td className = "temp">
              <div className = "skill-img-box">
                <img className = "skill-img" src = {this.props.imgsrc}/>
              </div>
            </td>
            <td>
              <div className = "skill-name">
                <p>{this.props.skillName}</p>
              </div>
              <div className = "skill-detail">
                <Description info = {this.props.info}/>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    );
  }
});

export default Skillbox;
