import React from 'react';
import ReactDOM from 'react-dom';
import Profile from './jaehyo_profile.js';

var Jaehyo = React.createClass ({
    getInitialState() {
        return {
          search:"",      /* STATE : 0 for 회원 관리, 1 for 건의사항 */
          j_TAG : ["#96년생","#케이웹정회원","#안경","#스터디","#힘들다","#아어아어ㅏㅇㅇ", "#남자", "#케이웹화이팅!"],
          m_TAG : ["#95년생","#선배님","#복학생","#PPT발표","#사진너무작아요!","#남자","#케이웹정회원"],
          s_TAG : ["#95년생","#15누님","#여자","#안경","#강아지졸귀탱","#케이웹정회원","#긴머리"],
          h_TAG : ["#96년생","#윤깐식","#안경","#겐지충","#남자","#케이웹총무","#사진은왜채호경이냐"]
        };
    },
    serach_hash : function(){
        var keyword = document.getElementById("search_engine").value;
        var check = 0;
        for (var i = 0; i < this.state.j_TAG.length; ++i){
            var str = this.state.j_TAG[i];
            console.log (keyword + " " + str);
            if(keyword == str){
                check = 1;
                document.getElementById("jaehyo").style.display = 'block';
            }
        }
        if(check == 0){
            document.getElementById("jaehyo").style.display = 'none';
        }

        check = 0;
        for (var i = 0; i < this.state.m_TAG.length; ++i){
            var str = this.state.m_TAG[i];
            if(keyword == str){
                check = 1;
                document.getElementById("myunghun").style.display = 'block';
            }
        }
        if(check == 0){
            document.getElementById("myunghun").style.display = 'none';
        }

        check = 0;
        for (var i = 0; i < this.state.s_TAG.length; ++i){
            var str = this.state.s_TAG[i];
            if(keyword == str){
                check = 1;
                document.getElementById("sora").style.display = 'block';
            }
        }
        if(check == 0){
            document.getElementById("sora").style.display = 'none';
        }

        check = 0;
        for (var i = 0; i < this.state.h_TAG.length; ++i){
            var str = this.state.h_TAG[i];
            if(keyword == str){
                check = 1;
                document.getElementById("hyunsik").style.display = 'block';
            }
        }
        if(check == 0){
            document.getElementById("hyunsik").style.display = 'none';
        }

        if(keyword.length == 0){
            document.getElementById("jaehyo").style.display = "block";
            document.getElementById("myunghun").style.display = "block";
            document.getElementById("sora").style.display = "block";
            document.getElementById("hyunsik").style.display = "block";
        }

        this.setState({
            search:keyword
        });
    },
    render: function () {
        return (
      		<div>
                <div className = "search_div">
                    <table>
                        <tbody>
                            <tr>
                            <th>
                                <input id="search_engine" type="text" placeholder="해쉬태그를 입력하세요" />
                            </th>
                            <td>
                                <button id="search_button" onClick={this.serach_hash.bind(this)}>검색</button>
                            </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div id="jaehyo">
                    <Profile NAME="유재효" SRC="./image/bonobono.jpg" TAG={this.state.j_TAG} keyword={this.state.search} />
                </div>
                <div id="myunghun">
                    <Profile NAME="강명훈" SRC="./image/myunghun.jpg" TAG={this.state.m_TAG} keyword={this.state.search} />
                </div>
                <div id="sora">
                    <Profile NAME="이소라" SRC="./image/sora.jpg" TAG={this.state.s_TAG} keyword={this.state.search} />
                </div>
                <div id="hyunsik">
                    <Profile NAME="윤현식" SRC="./image/hyunsik.jpg" TAG={this.state.h_TAG} keyword={this.state.search} />
                </div>

            </div>
        );
    }
});

export default Jaehyo;