export const SET_HYUNSIK = 'SET_HYUNSIK';

export function setHyunsikState(value) {
    return {
        type: SET_HYUNSIK,
        val: value
    };
}